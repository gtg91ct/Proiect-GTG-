package com.example.rest_service;

	public record Greeting(long id, String content) {
		
	}

